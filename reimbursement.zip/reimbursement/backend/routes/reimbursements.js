// routes/reimbursements.js - CORRECTED VERSION
const express = require('express');
const router = express.Router(); // ✅ Use Express Router

// Mock controller functions
const reimbursementController = {
    getReimbursements: (req, res) => {
        res.json({ message: 'Get reimbursements' });
    },
    createReimbursement: (req, res) => {
        res.json({ message: 'Create reimbursement', data: req.body });
    },
    updateReimbursementStatus: (req, res) => {
        res.json({ 
            message: 'Update reimbursement status', 
            id: req.params.id, 
            status: req.body.status 
        });
    },
    deleteReimbursement: (req, res) => {
        res.json({ message: 'Delete reimbursement', id: req.params.id });
    }
};

// Mock middleware (replace with your actual auth middleware)
const authenticate = (req, res, next) => {
    // Your authentication logic here
    req.user = { id: 1, role: 'employee' }; // Mock user
    next();
};

const authorize = (roles) => {
    return (req, res, next) => {
        // Your authorization logic here
        if (roles.includes(req.user.role)) {
            next();
        } else {
            res.status(403).json({ error: 'Access denied' });
        }
    };
};

// Routes
router.get('/', authenticate, reimbursementController.getReimbursements);
router.post('/', authenticate, reimbursementController.createReimbursement);
router.put('/:id', authenticate, authorize(['manager']), reimbursementController.updateReimbursementStatus);
router.delete('/:id', authenticate, reimbursementController.deleteReimbursement);

module.exports = router;