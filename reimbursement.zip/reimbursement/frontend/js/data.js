// Mock database for Phase 1
const users = [
    { id: 1, username: 'employee1', password: 'password123', role: 'employee', name: 'John Doe' },
    { id: 2, username: 'employee2', password: 'password123', role: 'employee', name: 'Sarah Wilson' },
    { id: 3, username: 'manager', password: 'password123', role: 'manager', name: 'Mr. Smith' }
];

// Sample initial reimbursements
const initialReimbursements = [
    { 
        id: 1, 
        user_id: 1, 
        employee_name: 'John Doe',
        date: '2024-01-15', 
        description: 'Office supplies - pens, notebooks, stapler', 
        amount: 45.50, 
        category: 'Office', 
        status: 'Approved',
        receipt: 'receipt_001.pdf',
        submitted_at: '2024-01-15 10:30:00'
    },
    { 
        id: 2, 
        user_id: 1, 
        employee_name: 'John Doe',
        date: '2024-01-18', 
        description: 'Client business lunch at Italian Restaurant', 
        amount: 75.00, 
        category: 'Meal', 
        status: 'Pending',
        receipt: 'receipt_002.pdf',
        submitted_at: '2024-01-18 14:20:00'
    },
    { 
        id: 3, 
        user_id: 2, 
        employee_name: 'Sarah Wilson',
        date: '2024-01-10', 
        description: 'Train ticket for client meeting in Boston', 
        amount: 120.00, 
        category: 'Travel', 
        status: 'Rejected',
        receipt: 'receipt_003.pdf',
        submitted_at: '2024-01-10 08:45:00'
    },
    { 
        id: 4, 
        user_id: 2, 
        employee_name: 'Sarah Wilson',
        date: '2024-01-20', 
        description: 'Online web development course subscription', 
        amount: 89.99, 
        category: 'Training', 
        status: 'Pending',
        receipt: 'receipt_004.pdf',
        submitted_at: '2024-01-20 16:10:00'
    }
];

// localStorage wrapper for data persistence
const storage = {
    // User management
    getUsers: () => {
        return users; // Static users for Phase 1
    },
    
    getReimbursements: () => {
        const stored = localStorage.getItem('reimbursements');
        if (!stored) {
            // Initialize with sample data
            localStorage.setItem('reimbursements', JSON.stringify(initialReimbursements));
            return initialReimbursements;
        }
        return JSON.parse(stored);
    },
    
    saveReimbursements: (data) => {
        localStorage.setItem('reimbursements', JSON.stringify(data));
    },
    
    getCurrentUser: () => {
        return JSON.parse(localStorage.getItem('currentUser'));
    },
    
    setCurrentUser: (user) => {
        localStorage.setItem('currentUser', JSON.stringify(user));
    },
    
    logout: () => {
        localStorage.removeItem('currentUser');
    },
    
    // Utility functions
    generateId: () => {
        return Date.now() + Math.floor(Math.random() * 1000);
    },
    
    getCurrentTimestamp: () => {
        return new Date().toISOString().slice(0, 19).replace('T', ' ');
    }
};

// Initialize data if not exists
if (!localStorage.getItem('reimbursements')) {
    storage.saveReimbursements(initialReimbursements);
}