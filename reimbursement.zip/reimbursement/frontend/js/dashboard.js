// Dashboard functionality for Phase 1
class Dashboard {
    constructor() {
        this.currentUser = storage.getCurrentUser();
        this.reimbursements = storage.getReimbursements();
        this.init();
    }

    init() {
        if (!this.currentUser) {
            window.location.href = 'index.html';
            return;
        }

        this.displayUserInfo();
        this.setupEventListeners();
        this.loadReimbursements();
    }

    displayUserInfo() {
        const welcomeElement = document.getElementById('userWelcome');
        if (welcomeElement) {
            welcomeElement.textContent = `Welcome, ${this.currentUser.name} (${this.currentUser.role})`;
        }
        
        // Show appropriate view based on role
        if (this.currentUser.role === 'manager') {
            document.getElementById('managerView').classList.remove('hidden');
            this.loadManagerStats();
        } else {
            document.getElementById('employeeView').classList.remove('hidden');
            this.loadEmployeeStats();
        }
    }

    setupEventListeners() {
        // Logout functionality
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                if (confirm('Are you sure you want to logout?')) {
                    storage.logout();
                    window.location.href = 'index.html';
                }
            });
        }

        // New reimbursement form
        const reimbursementForm = document.getElementById('reimbursementForm');
        if (reimbursementForm) {
            reimbursementForm.addEventListener('submit', (e) => {
                this.handleNewReimbursement(e);
            });
        }

        // Set today's date as default
        const dateField = document.getElementById('date');
        if (dateField) {
            dateField.valueAsDate = new Date();
        }
    }

    loadReimbursements() {
        if (this.currentUser.role === 'employee') {
            this.renderEmployeeReimbursements();
        } else {
            this.renderManagerReimbursements();
        }
    }

    loadEmployeeStats() {
        const userReimbursements = this.reimbursements.filter(r => r.user_id === this.currentUser.id);
        
        const pendingCount = userReimbursements.filter(r => r.status === 'Pending').length;
        const approvedCount = userReimbursements.filter(r => r.status === 'Approved').length;
        const rejectedCount = userReimbursements.filter(r => r.status === 'Rejected').length;
        
        document.getElementById('myPendingCount').textContent = pendingCount;
        document.getElementById('myApprovedCount').textContent = approvedCount;
        document.getElementById('myRejectedCount').textContent = rejectedCount;
    }

    loadManagerStats() {
        const pendingCount = this.reimbursements.filter(r => r.status === 'Pending').length;
        const approvedCount = this.reimbursements.filter(r => r.status === 'Approved').length;
        const rejectedCount = this.reimbursements.filter(r => r.status === 'Rejected').length;
        const totalCount = this.reimbursements.length;

        document.getElementById('pendingCount').textContent = pendingCount;
        document.getElementById('approvedCount').textContent = approvedCount;
        document.getElementById('rejectedCount').textContent = rejectedCount;
        document.getElementById('totalCount').textContent = totalCount;
    }

    renderEmployeeReimbursements() {
        const container = document.getElementById('employeeReimbursements');
        const userReimbursements = this.reimbursements.filter(r => r.user_id === this.currentUser.id);

        if (userReimbursements.length === 0) {
            container.innerHTML = '<div class="empty-state">No reimbursement requests found. Submit your first request above!</div>';
            return;
        }

        container.innerHTML = `
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${userReimbursements.map(req => `
                        <tr>
                            <td>${this.formatDate(req.date)}</td>
                            <td>${req.description}</td>
                            <td>${req.category}</td>
                            <td>$${req.amount.toFixed(2)}</td>
                            <td><span class="status ${req.status.toLowerCase()}">${req.status}</span></td>
                            <td>
                                ${req.status === 'Pending' ? 
                                    `<button onclick="dashboard.deleteReimbursement(${req.id})" class="btn-danger">Delete</button>` : 
                                    '<span class="action-completed">Completed</span>'
                                }
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    renderManagerReimbursements() {
        const container = document.getElementById('managerReimbursements');
        
        if (this.reimbursements.length === 0) {
            container.innerHTML = '<div class="empty-state">No reimbursement requests found.</div>';
            return;
        }

        // Sort by date (newest first)
        const sortedReimbursements = [...this.reimbursements].sort((a, b) => 
            new Date(b.date) - new Date(a.date)
        );

        container.innerHTML = `
            <table>
                <thead>
                    <tr>
                        <th>Employee</th>
                        <th>Date</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${sortedReimbursements.map(req => `
                        <tr>
                            <td><strong>${req.employee_name}</strong></td>
                            <td>${this.formatDate(req.date)}</td>
                            <td>${req.description}</td>
                            <td>${req.category}</td>
                            <td>$${req.amount.toFixed(2)}</td>
                            <td><span class="status ${req.status.toLowerCase()}">${req.status}</span></td>
                            <td>
                                ${req.status === 'Pending' ? `
                                    <button onclick="dashboard.updateStatus(${req.id}, 'Approved')" class="btn-success">Approve</button>
                                    <button onclick="dashboard.updateStatus(${req.id}, 'Rejected')" class="btn-danger">Reject</button>
                                ` : '<span class="action-completed">Resolved</span>'
                                }
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    handleNewReimbursement(e) {
        e.preventDefault();
        
        const formData = {
            id: storage.generateId(),
            user_id: this.currentUser.id,
            employee_name: this.currentUser.name,
            date: document.getElementById('date').value,
            description: document.getElementById('description').value.trim(),
            amount: parseFloat(document.getElementById('amount').value),
            category: document.getElementById('category').value,
            status: 'Pending',
            receipt: 'receipt_' + storage.generateId() + '.pdf',
            submitted_at: storage.getCurrentTimestamp()
        };

        // Basic validation
        if (formData.amount <= 0) {
            alert('Please enter a valid amount greater than 0.');
            return;
        }

        if (formData.description.length < 5) {
            alert('Please enter a meaningful description (at least 5 characters).');
            return;
        }

        this.reimbursements.push(formData);
        storage.saveReimbursements(this.reimbursements);
        
        alert('✅ Reimbursement submitted successfully!');
        this.renderEmployeeReimbursements();
        this.loadEmployeeStats();
        e.target.reset();
        document.getElementById('date').valueAsDate = new Date();
    }

    deleteReimbursement(id) {
        if (confirm('Are you sure you want to delete this reimbursement request? This action cannot be undone.')) {
            this.reimbursements = this.reimbursements.filter(req => req.id !== id);
            storage.saveReimbursements(this.reimbursements);
            this.renderEmployeeReimbursements();
            this.loadEmployeeStats();
        }
    }

    updateStatus(id, newStatus) {
        const reimbursement = this.reimbursements.find(req => req.id === id);
        if (reimbursement) {
            reimbursement.status = newStatus;
            storage.saveReimbursements(this.reimbursements);
            this.renderManagerReimbursements();
            this.loadManagerStats();
            
            // Show confirmation
            const statusText = newStatus === 'Approved' ? 'approved' : 'rejected';
            alert(`✅ Request ${statusText} successfully!`);
        }
    }

    formatDate(dateString) {
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        return new Date(dateString).toLocaleDateString('en-US', options);
    }
}

// Add some CSS for empty states and action completed
const additionalStyles = `
    .empty-state {
        text-align: center;
        padding: 3rem;
        color: #7f8c8d;
        font-style: italic;
        background: #f8f9fa;
        border-radius: 8px;
    }
    
    .action-completed {
        color: #7f8c8d;
        font-style: italic;
    }
    
    .file-input-wrapper small {
        color: #7f8c8d;
    }
`;

// Inject additional styles
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);

// Initialize dashboard when page loads
let dashboard;
document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname.includes('dashboard.html')) {
        dashboard = new Dashboard();
    }
});