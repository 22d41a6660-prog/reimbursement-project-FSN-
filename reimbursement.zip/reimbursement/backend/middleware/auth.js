// middleware/auth.js
const authenticate = (req, res, next) => {
    // Simple mock authentication for now
    // Replace with JWT or session-based auth later
    const token = req.headers.authorization;
    
    if (!token) {
        return res.status(401).json({ error: 'No token provided' });
    }
    
    // Mock user (replace with actual token verification)
    req.user = { 
        id: 1, 
        username: 'employee1', 
        role: 'employee',
        name: 'John Doe'
    };
    
    next();
};

const authorize = (roles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'Not authenticated' });
        }
        
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        next();
    };
};

module.exports = { authenticate, authorize };