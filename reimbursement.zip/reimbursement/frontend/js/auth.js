// Authentication logic for Phase 1
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            const users = storage.getUsers();
            const user = users.find(u => u.username === username && u.password === password);
            
            if (user) {
                // Store current user and redirect to dashboard
                storage.setCurrentUser(user);
                window.location.href = 'dashboard.html';
            } else {
                alert('Invalid credentials! Please select a user from the dropdown.');
            }
        });
        
        // Auto-fill password and make it visible what we're doing
        const passwordField = document.getElementById('password');
        const usernameSelect = document.getElementById('username');
        
        usernameSelect.addEventListener('change', function() {
            if (this.value) {
                passwordField.value = 'password123';
            } else {
                passwordField.value = '';
            }
        });
    }
    
    // Redirect to login if trying to access dashboard without authentication
    if (window.location.pathname.includes('dashboard.html')) {
        if (!storage.getCurrentUser()) {
            window.location.href = 'index.html';
        }
    }
});