// frontend/js/app.js
console.log('Reimbursements Management System - Frontend Loaded');

// Test API connection
async function testAPI() {
    try {
        const response = await fetch('/api/test');
        const data = await response.json();
        console.log('API Test:', data);
    } catch (error) {
        console.error('API Test Failed:', error);
    }
}

// Run test when page loads
document.addEventListener('DOMContentLoaded', testAPI);