// routes/auth.js - CORRECTED VERSION
const express = require('express');
const router = express.Router(); // ✅ Use Express Router

// Mock controller functions (replace with your actual logic)
const authController = {
    login: (req, res) => {
        // Your login logic here
        res.json({ message: 'Login endpoint', user: req.body });
    },
    logout: (req, res) => {
        // Your logout logic here
        res.json({ message: 'Logout successful' });
    },
    getCurrentUser: (req, res) => {
        // Your get user logic here
        res.json({ user: req.user });
    }
};

// ✅ Correct route definitions
router.post('/login', authController.login);
router.post('/logout', authController.logout);
router.get('/me', authController.getCurrentUser);

module.exports = router;