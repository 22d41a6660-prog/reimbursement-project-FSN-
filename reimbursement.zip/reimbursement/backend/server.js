// server.js - UPDATED VERSION
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Check if frontend directory exists, then serve static files
const frontendPath = path.join(__dirname, '../frontend');
if (fs.existsSync(frontendPath)) {
    app.use(express.static(frontendPath));
    console.log('✅ Frontend files served from:', frontendPath);
} else {
    console.log('⚠️  Frontend directory not found, serving API only');
}

// Import routes
const authRoutes = require('./routes/auth');
const reimbursementRoutes = require('./routes/reimbursements');

// Use routes
app.use('/api/auth', authRoutes);
app.use('/api/reimbursements', reimbursementRoutes);

// Basic test route
app.get('/api/test', (req, res) => {
    res.json({ 
        message: 'Backend is working!', 
        timestamp: new Date().toISOString(),
        endpoints: {
            auth: '/api/auth',
            reimbursements: '/api/reimbursements',
            test: '/api/test'
        }
    });
});

// API documentation route
app.get('/api', (req, res) => {
    res.json({
        name: 'Reimbursements Management API',
        version: '1.0.0',
        endpoints: {
            'GET /api/test': 'Test API connection',
            'POST /api/auth/login': 'User login',
            'POST /api/auth/logout': 'User logout',
            'GET /api/auth/me': 'Get current user',
            'GET /api/reimbursements': 'Get reimbursements',
            'POST /api/reimbursements': 'Create reimbursement',
            'PUT /api/reimbursements/:id': 'Update reimbursement status',
            'DELETE /api/reimbursements/:id': 'Delete reimbursement'
        }
    });
});

// Only serve frontend if it exists
app.get('*', (req, res) => {
    const frontendIndex = path.join(__dirname, '../frontend/index.html');
    if (fs.existsSync(frontendIndex)) {
        res.sendFile(frontendIndex);
    } else {
        res.json({
            message: 'Reimbursements Management Backend API',
            note: 'Frontend not found. Create frontend directory or use API endpoints directly.',
            api_docs: '/api'
        });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log(`📚 API Documentation: http://localhost:${PORT}/api`);
    console.log(`🧪 Test endpoint: http://localhost:${PORT}/api/test`);
});